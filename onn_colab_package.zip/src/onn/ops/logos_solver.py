"""
LOGOS (Logical Ontological Generator for Self-Adjustment) Operator

The Correction Operator in the ONN Trinity.
Iteratively projects the graph onto the Constraint Manifold C using PyTorch autograd.

Core Math (from spec/02_onn_math_spec.md Section 2.2):
    S^{k+1} = Π_C ( S^k - η ∇_S L_total(S^k, E^k) )

Loss Function (from spec/02_onn_math_spec.md Section 4.1):
    L_total = λ_data * L_data + λ_phys * L_phys + λ_logic * L_logic

Where:
    L_data  = Σ_i ||S_i - S_i^raw||²           (Data Fidelity)
    L_phys  = Σ_{i≠j} ReLU(Sim(B_i,B_j) - θ)   (Physical Validity)
    L_logic = Σ_{(i,j)∈E} w_ij ||S_i + r_ij - S_j||²  (Logical Consistency / TransE)

Hyperparameters (from spec/02_onn_math_spec.md Section 4.2):
    λ_data = 1.0, λ_phys = 10.0, λ_logic = 2.0

Framework-agnostic: No ROS2, DDS, or external framework dependencies.
Uses PyTorch for automatic differentiation.

Reference:
    - spec/02_onn_math_spec.md
    - spec/10_architecture.ir.yml -> modules[logos_consensus_solver]
    - spec/11_interfaces.ir.yml -> data_schemas[StabilizedGraph]
"""

from __future__ import annotations

import torch
import torch.nn.functional as F
import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple
import logging

from onn.core.tensors import (
    SemanticNode,
    SemanticEdge,
    RawSemanticGraph,
    StabilizedGraph,
    BOUND_TENSOR_DIM,
    FORM_TENSOR_DIM,
    INTENT_TENSOR_DIM,
)

logger = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
# Constants from spec/02_onn_math_spec.md
# -----------------------------------------------------------------------------

STATE_DIM = BOUND_TENSOR_DIM + FORM_TENSOR_DIM + INTENT_TENSOR_DIM  # 64


# -----------------------------------------------------------------------------
# Configuration (from spec/02_onn_math_spec.md Section 4.2)
# -----------------------------------------------------------------------------

@dataclass
class LOGOSConfig:
    """
    Configuration for the LOGOS solver.

    Hyperparameters from spec/02_onn_math_spec.md Section 4.2:
        λ_data = 1.0   : Trust sensors significantly
        λ_phys = 10.0  : Physics violations are expensive
        λ_logic = 2.0  : Logic guides the structure
    """
    # Loss weights (spec Section 4.2)
    lambda_data: float = 1.0
    lambda_phys: float = 10.0
    lambda_logic: float = 2.0

    # Physical constraint threshold
    overlap_threshold: float = 0.5

    # Solver parameters (spec Section 5.2)
    max_iterations: int = 10
    learning_rate: float = 0.01
    tolerance: float = 1e-6

    # Edge pruning
    edge_prune_threshold: float = 0.1

    # Device
    device: str = "cpu"


# -----------------------------------------------------------------------------
# Loss Functions (from spec/02_onn_math_spec.md Section 4.1)
# -----------------------------------------------------------------------------

def compute_data_loss(
    state: torch.Tensor,
    state_raw: torch.Tensor
) -> torch.Tensor:
    """
    Data Fidelity Loss: Keep state close to observation.

    L_data = Σ_i ||S_i - S_i^raw||²

    Reference: spec/02_onn_math_spec.md Section 4.1 Equation (1)

    Args:
        state: Current state tensor, shape (N, 64)
        state_raw: Raw observation state, shape (N, 64)

    Returns:
        Scalar loss tensor
    """
    diff = state - state_raw
    return torch.sum(diff ** 2)


def compute_phys_loss(
    state: torch.Tensor,
    overlap_threshold: float = 0.5
) -> torch.Tensor:
    """
    Physical Validity Loss: Penalize invalid overlaps.

    L_phys = Σ_{i≠j} ReLU(Sim(B_i, B_j) - θ_overlap)

    reference: spec/02_onn_math_spec.md Section 4.1 Equation (2)

    Args:
        state: Current state tensor, shape (N, 64)
        overlap_threshold: Unused in CPL_009 (retained for API compatibility)

    Returns:
        Scalar loss tensor
    """
    # CPL_009: Sphere Collision Penalty
    # L_phys = Σ_{i≠j} ReLU(R_i + R_j - ||p_i - p_j||)
    
    # Extract position (b_0:3) and radius (b_11)
    # Assumes SEGO populates these correctly (verified in CPL_009 SEGO update)
    pos = state[:, 0:3]      # (N, 3)
    radius = state[:, 11]    # (N,)

    # Compute pairwise Euclidean distance
    # shape: (N, N)
    dist_matrix = torch.cdist(pos, pos, p=2)

    # Compute sum of radii for all pairs
    # shape: (N, N) via broadcasting
    r_sum_matrix = radius.unsqueeze(1) + radius.unsqueeze(0)

    # Calculate penetration depth: (Ri + Rj) - dist
    # Positive value means collision (overlap)
    penetration = r_sum_matrix - dist_matrix

    # Apply ReLU to get penalty (0 if no collision)
    violation = F.relu(penetration)

    # Zero out diagonal (self-collision is always R+R - 0 > 0, but invalid physically)
    # Self-collision should be ignored as an object always overlaps itself
    n = state.shape[0]
    mask = ~torch.eye(n, dtype=torch.bool, device=state.device)
    violation = violation * mask.float()

    # Sum violations (divide by 2 because (i,j) and (j,i) are symmetric)
    loss = torch.sum(violation) / 2.0

    return loss


def compute_logic_loss(
    state: torch.Tensor,
    edge_indices: torch.Tensor,
    relation_embeddings: torch.Tensor,
    edge_weights: torch.Tensor
) -> torch.Tensor:
    """
    Logical Consistency Loss: TransE-style embedding loss.

    L_logic = Σ_{(i,j)∈E} w_ij ||S_i + r_ij - S_j||²

    Reference: spec/02_onn_math_spec.md Section 4.1 Equation (3)

    Args:
        state: Current state tensor, shape (N, 64)
        edge_indices: Edge source/target indices, shape (E, 2)
        relation_embeddings: r_ij vectors, shape (E, 64) or (E, 16) padded
        edge_weights: w_ij connection stiffness, shape (E,)

    Returns:
        Scalar loss tensor
    """
    if edge_indices.shape[0] == 0:
        return torch.tensor(0.0, device=state.device)

    source_idx = edge_indices[:, 0]  # (E,)
    target_idx = edge_indices[:, 1]  # (E,)

    # Get source and target states
    s_i = state[source_idx]  # (E, 64)
    s_j = state[target_idx]  # (E, 64)

    # Pad relation embeddings to state dim if needed
    if relation_embeddings.shape[1] < STATE_DIM:
        padding = torch.zeros(
            relation_embeddings.shape[0],
            STATE_DIM - relation_embeddings.shape[1],
            device=relation_embeddings.device
        )
        relation_embeddings = torch.cat([relation_embeddings, padding], dim=1)

    # TransE: S_i + r_ij ≈ S_j
    translation_error = s_i + relation_embeddings - s_j  # (E, 64)

    # Weighted squared error
    error_norm_sq = torch.sum(translation_error ** 2, dim=1)  # (E,)
    weighted_error = edge_weights * error_norm_sq  # (E,)

    return torch.sum(weighted_error)


def compute_total_loss(
    state: torch.Tensor,
    state_raw: torch.Tensor,
    edge_indices: torch.Tensor,
    relation_embeddings: torch.Tensor,
    edge_weights: torch.Tensor,
    config: LOGOSConfig
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    Total Loss Function for LOGOS.

    L_total = λ_data * L_data + λ_phys * L_phys + λ_logic * L_logic

    Reference: spec/02_onn_math_spec.md Section 4.1

    Args:
        state: Current state tensor, shape (N, 64)
        state_raw: Raw observation state, shape (N, 64)
        edge_indices: Edge source/target indices, shape (E, 2)
        relation_embeddings: r_ij vectors, shape (E, d)
        edge_weights: w_ij connection stiffness, shape (E,)
        config: LOGOS configuration with lambda weights

    Returns:
        Tuple of (total_loss, loss_breakdown_dict)
    """
    l_data = compute_data_loss(state, state_raw)
    l_phys = compute_phys_loss(state, config.overlap_threshold)
    l_logic = compute_logic_loss(state, edge_indices, relation_embeddings, edge_weights)

    total = (
        config.lambda_data * l_data +
        config.lambda_phys * l_phys +
        config.lambda_logic * l_logic
    )

    breakdown = {
        "data": float(l_data.detach()),
        "phys": float(l_phys.detach()),
        "logic": float(l_logic.detach()),
        "total": float(total.detach()),
    }

    return total, breakdown


# -----------------------------------------------------------------------------
# Projection Operator (from spec/02_onn_math_spec.md Section 5.1)
# -----------------------------------------------------------------------------

def project_to_manifold(state: torch.Tensor) -> torch.Tensor:
    """
    Hard Projection Π_C: Project state onto constraint manifold.

    From spec/02_onn_math_spec.md Section 5.1:
        - bound_tensor = normalize(bound_tensor)  # Unit sphere
        - intent_tensor = clamp(intent_tensor, 0, 1)  # Probabilities

    Args:
        state: State tensor, shape (N, 64)

    Returns:
        Projected state tensor, shape (N, 64)
    """
    # Split into components
    bound = state[:, :BOUND_TENSOR_DIM]
    form = state[:, BOUND_TENSOR_DIM:BOUND_TENSOR_DIM + FORM_TENSOR_DIM]
    intent = state[:, BOUND_TENSOR_DIM + FORM_TENSOR_DIM:]

    # Project bound tensor to unit sphere
    bound_norm = torch.norm(bound, p=2, dim=1, keepdim=True)
    bound_norm = torch.clamp(bound_norm, min=1e-8)  # Avoid division by zero
    bound_projected = bound / bound_norm

    # Clamp intent tensor to [0, 1] (affordance probabilities)
    intent_projected = torch.clamp(intent, 0.0, 1.0)

    # Form tensor: no projection (can vary freely)
    form_projected = form

    return torch.cat([bound_projected, form_projected, intent_projected], dim=1)


# -----------------------------------------------------------------------------
# LOGOS Solver
# -----------------------------------------------------------------------------

@dataclass
class SolverResult:
    """Result of a LOGOS solve operation."""
    final_state: torch.Tensor
    iterations: int
    converged: bool
    energy_history: List[float]
    final_breakdown: Dict[str, float]


class LOGOSSolver:
    """
    The LOGOS Operator implementation using PyTorch autograd.

    Solves for topological validity by iteratively projecting
    the semantic graph onto the constraint manifold.

    Algorithm (from spec/02_onn_math_spec.md Section 5.1):
        1. Initialize S from raw observation
        2. For k in range(max_iterations):
            a. loss = compute_total_energy(S, edges, config)
            b. grads = torch.autograd.grad(loss, S)
            c. S = S - learning_rate * grads
            d. S = project_to_manifold(S)  # Hard constraints
            e. if loss < tolerance: break
        3. Return G_valid(S, edges)

    Hypothesis H-01: Energy monotonically decreases during the loop.

    Reference:
        - spec/02_onn_math_spec.md Section 5.1
        - spec/10_architecture.ir.yml -> modules[logos_consensus_solver]
    """

    def __init__(self, config: Optional[LOGOSConfig] = None):
        """
        Initialize the LOGOS solver.

        Args:
            config: Solver configuration. Uses defaults from spec if None.
        """
        self.config = config or LOGOSConfig()
        self.device = torch.device(self.config.device)
        self._last_result: Optional[SolverResult] = None
        
        # === CPL_003: Hold last valid graph for safety ===
        self._last_valid_graph: Optional[StabilizedGraph] = None

    def solve(
        self,
        raw_graph: RawSemanticGraph,
        warm_start: bool = False
    ) -> StabilizedGraph:
        """
        Solve for a topologically valid graph.

        This is the main entry point for the LOGOS operator.

        Args:
            raw_graph: Unstabilized graph from SEGO
            warm_start: Whether to use previous solution as starting point

        Returns:
            StabilizedGraph with constraint-satisfied nodes and pruned edges

        Raises:
            ValueError: If raw_graph has no nodes

        Reference: spec/10_architecture.ir.yml -> modules[logos_consensus_solver]
        """
        if not raw_graph.nodes:
            raise ValueError("Cannot solve empty graph: no nodes provided")

        # Convert graph to tensors
        state_raw, node_id_map = self._nodes_to_tensor(raw_graph.nodes)
        edge_indices, relation_embeddings, edge_weights = self._edges_to_tensors(
            raw_graph.edge_candidates, node_id_map
        )

        # Initialize state (optionally from warm start)
        if warm_start and self._last_result is not None:
            state = self._last_result.final_state.clone().detach()
            # Resize if node count changed
            if state.shape[0] != state_raw.shape[0]:
                state = state_raw.clone()
        else:
            state = state_raw.clone()

        # Enable gradient tracking
        state.requires_grad_(True)

        # Optimization loop (spec Section 5.1)
        energy_history: List[float] = []
        converged = False

        for iteration in range(self.config.max_iterations):
            # Step 1: Compute total loss with gradients
            total_loss, breakdown = compute_total_loss(
                state, state_raw, edge_indices, relation_embeddings, edge_weights,
                self.config
            )
            energy_history.append(breakdown["total"])

            # Log for H-01 verification (energy should decrease)
            if len(energy_history) > 1:
                delta = energy_history[-1] - energy_history[-2]
                logger.debug(f"Iteration {iteration}: E={breakdown['total']:.6f}, ΔE={delta:.6f}")

            # Step 2: Check convergence (spec Section 5.2)
            if total_loss.item() < self.config.tolerance:
                converged = True
                logger.info(f"LOGOS converged at iteration {iteration}")
                break

            # Step 3: Compute gradients via autograd
            grads = torch.autograd.grad(total_loss, state, create_graph=False)[0]

            # Step 4: Gradient descent step
            with torch.no_grad():
                state = state - self.config.learning_rate * grads

                # Step 5: Project to manifold (hard constraints)
                state = project_to_manifold(state)

            # Re-enable gradients for next iteration
            state.requires_grad_(True)

        # Store result for potential warm start
        self._last_result = SolverResult(
            final_state=state.detach(),
            iterations=iteration + 1,
            converged=converged,
            energy_history=energy_history,
            final_breakdown=breakdown
        )

        # Convert back to graph structures
        stabilized_nodes = self._tensor_to_nodes(state.detach(), node_id_map)
        pruned_edges = self._prune_edges(raw_graph.edge_candidates, node_id_map)

        # === CPL_003: Mark validity and iteration count ===
        result_graph = StabilizedGraph(
            timestamp_ns=raw_graph.timestamp_ns,
            nodes=stabilized_nodes,
            edges=pruned_edges,
            global_energy=breakdown["total"],
            is_valid=converged,
            iterations_used=iteration + 1
        )

        # === CPL_003: Cache valid graph for fallback ===
        if converged:
            self._last_valid_graph = result_graph
        else:
            logger.warning(
                f"LOGOS did not converge after {iteration + 1} iterations. "
                f"is_valid=False, final_energy={breakdown['total']:.6f}"
            )

        return result_graph

    def _nodes_to_tensor(
        self,
        nodes: List[SemanticNode]
    ) -> Tuple[torch.Tensor, Dict[int, int]]:
        """
        Convert list of SemanticNodes to a state tensor.

        Returns:
            state: Tensor of shape (N, 64)
            node_id_map: Dict mapping node_id -> tensor row index
        """
        node_id_map = {node.node_id: i for i, node in enumerate(nodes)}

        states = []
        for node in nodes:
            combined = np.concatenate([
                node.bound_tensor,
                node.form_tensor,
                node.intent_tensor
            ])
            states.append(combined)

        state = torch.tensor(np.array(states), dtype=torch.float32, device=self.device)
        return state, node_id_map

    def _edges_to_tensors(
        self,
        edges: List[SemanticEdge],
        node_id_map: Dict[int, int]
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Convert list of SemanticEdges to tensors.

        Returns:
            edge_indices: Tensor of shape (E, 2)
            relation_embeddings: Tensor of shape (E, d)
            edge_weights: Tensor of shape (E,)
        """
        if not edges:
            return (
                torch.zeros((0, 2), dtype=torch.long, device=self.device),
                torch.zeros((0, STATE_DIM), dtype=torch.float32, device=self.device),
                torch.zeros((0,), dtype=torch.float32, device=self.device)
            )

        indices = []
        relations = []
        weights = []

        for edge in edges:
            if edge.source_id in node_id_map and edge.target_id in node_id_map:
                indices.append([node_id_map[edge.source_id], node_id_map[edge.target_id]])
                relations.append(edge.relation_embedding)
                weights.append(edge.effective_strength())

        if not indices:
            return (
                torch.zeros((0, 2), dtype=torch.long, device=self.device),
                torch.zeros((0, STATE_DIM), dtype=torch.float32, device=self.device),
                torch.zeros((0,), dtype=torch.float32, device=self.device)
            )

        edge_indices = torch.tensor(indices, dtype=torch.long, device=self.device)
        relation_embeddings = torch.tensor(np.array(relations), dtype=torch.float32, device=self.device)
        edge_weights = torch.tensor(weights, dtype=torch.float32, device=self.device)

        return edge_indices, relation_embeddings, edge_weights

    def _tensor_to_nodes(
        self,
        state: torch.Tensor,
        node_id_map: Dict[int, int]
    ) -> List[SemanticNode]:
        """Convert state tensor back to SemanticNodes."""
        reverse_map = {v: k for k, v in node_id_map.items()}
        state_np = state.cpu().numpy()

        nodes = []
        for i in range(state.shape[0]):
            node_id = reverse_map[i]
            s = state_np[i]

            node = SemanticNode(
                node_id=node_id,
                bound_tensor=s[:BOUND_TENSOR_DIM].copy(),
                form_tensor=s[BOUND_TENSOR_DIM:BOUND_TENSOR_DIM + FORM_TENSOR_DIM].copy(),
                intent_tensor=s[BOUND_TENSOR_DIM + FORM_TENSOR_DIM:].copy()
            )
            nodes.append(node)

        return nodes

    def _prune_edges(
        self,
        edges: List[SemanticEdge],
        node_id_map: Dict[int, int]
    ) -> List[SemanticEdge]:
        """Prune edges with low effective strength."""
        valid_edges = []
        for edge in edges:
            if edge.source_id not in node_id_map or edge.target_id not in node_id_map:
                continue
            if edge.effective_strength() >= self.config.edge_prune_threshold:
                valid_edges.append(edge.copy())
        return valid_edges

    def get_last_result(self) -> Optional[SolverResult]:
        """Get the result from the last solve call."""
        return self._last_result

    def reset(self) -> None:
        """Reset solver state (clears warm start cache and valid graph cache)."""
        self._last_result = None
        self._last_valid_graph = None

    def get_last_valid_graph(self) -> Optional[StabilizedGraph]:
        """
        Get the last successfully converged graph.
        
        CPL_003: Returns the last graph where is_valid=True,
        or None if no valid graph has been computed.
        """
        return self._last_valid_graph


# -----------------------------------------------------------------------------
# Factory Functions
# -----------------------------------------------------------------------------

def create_default_solver() -> LOGOSSolver:
    """
    Create a LOGOS solver with default configuration from spec.

    Uses hyperparameters from spec/02_onn_math_spec.md Section 4.2:
        λ_data = 1.0, λ_phys = 10.0, λ_logic = 2.0
    """
    return LOGOSSolver(LOGOSConfig())


def create_realtime_solver() -> LOGOSSolver:
    """
    Create a LOGOS solver optimized for real-time operation.

    Uses fixed iteration budget (5) as mentioned in spec/00_high_level_plan.md.
    """
    config = LOGOSConfig(
        max_iterations=5,
        learning_rate=0.1,  # Larger step for faster convergence
    )
    return LOGOSSolver(config)
