"""ONN ES Training Package.

Provides CMA-ES optimization for ONN solver hyperparameters.

Reference:
    spec/20_impl_plan.ir.yml: IMPL_020, IMPL_021
"""

from onn.es.ask_tell import (
    ESConfig,
    CMAESState,
    CMAESTrainer,
    Candidate,
    create_default_trainer,
    create_trainer_for_params,
    create_trainer_with_w_lin,
)

from onn.es.fitness import (
    FitnessConfig,
    EpisodeStep,
    EvalMetrics,
    evaluate_episode,
    evaluate_candidate,
    aggregate_metrics,
    compute_fitness,
    generate_synthetic_episode,
)

from onn.es.schedule import (
    ScheduleConfig,
    linear_schedule,
    exponential_schedule,
    cosine_schedule,
    apply_schedule,
    create_warmup_schedule,
)

__all__ = [
    # Ask/Tell
    "ESConfig",
    "CMAESState",
    "CMAESTrainer",
    "Candidate",
    "create_default_trainer",
    "create_trainer_for_params",
    "create_trainer_with_w_lin",
    # Fitness
    "FitnessConfig",
    "EpisodeStep",
    "EvalMetrics",
    "evaluate_episode",
    "evaluate_candidate",
    "aggregate_metrics",
    "compute_fitness",
    "generate_synthetic_episode",
    # Schedule
    "ScheduleConfig",
    "linear_schedule",
    "exponential_schedule",
    "cosine_schedule",
    "apply_schedule",
    "create_warmup_schedule",
]
