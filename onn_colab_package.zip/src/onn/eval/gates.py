"""Acceptance Gates for ONN Validation.

This module implements gate-based validation that determines whether
an ONN configuration is acceptable for deployment.

Gates:
1. Feasibility: V_mean ≤ ε_V (cycle constraints satisfied)
2. Fidelity: D_mean ≤ ε_D (observations respected)
3. Non-collapse: A_mean ≥ ε_A (embeddings not degenerate)
4. Responsiveness: Δt_mean ≤ ε_Δ (fast event recovery)

Reference:
    - spec/11_interfaces.ir.yml: GateReport
    - spec/20_impl_plan.ir.yml: IMPL_022

Author: Claude (via IMPL_022)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


# ==============================================================================
# CONFIGURATION
# ==============================================================================

@dataclass
class GateConfig:
    """Acceptance gate thresholds.
    
    Reference: User roadmap "Gate Definitions"
    """
    # Feasibility
    violation_max: float = 0.1          # ε_V,max: max allowed violation
    violation_mean: float = 0.05        # ε_V: mean allowed violation
    
    # Fidelity
    drift_max: float = 1.0              # ε_D: max allowed drift
    
    # Non-collapse
    collapse_min: float = 0.01          # ε_A: minimum variance
    
    # Responsiveness
    latency_max: float = 5.0            # ε_Δ: max recovery steps
    
    # Consistency (optional)
    contradiction_max: float = 0.05     # ε_C: max contradiction rate
    
    # Structural
    ricci_max: float = 100.0            # Max Ricci energy


@dataclass
class GateResult:
    """Individual gate evaluation result."""
    gate_id: str
    passed: bool
    value: float
    threshold: float
    description: str = ""


@dataclass 
class GateReport:
    """Gate evaluation report.
    
    Reference: spec/11_interfaces.ir.yml -> GateReport
    """
    passed: bool                        # Overall pass/fail
    failed_gates: List[str] = field(default_factory=list)
    gate_results: List[GateResult] = field(default_factory=list)
    metrics: Optional[Dict[str, float]] = None


# ==============================================================================
# GATE EVALUATION
# ==============================================================================

def evaluate_gates(
    metrics: Dict[str, float],
    config: Optional[GateConfig] = None,
) -> GateReport:
    """Check all gates and return pass/fail with details.
    
    Args:
        metrics: Dictionary with metric values (from metrics.py)
        config: Gate configuration with thresholds
        
    Returns:
        GateReport with overall result and details
    """
    if config is None:
        config = GateConfig()
    
    results = []
    failed = []
    
    # Gate 1: Feasibility (mean violation)
    violation_mean = metrics.get("violation_mean", metrics.get("violation", 0))
    passed = violation_mean <= config.violation_mean
    results.append(GateResult(
        gate_id="feasibility_mean",
        passed=passed,
        value=violation_mean,
        threshold=config.violation_mean,
        description=f"Mean violation ≤ {config.violation_mean}",
    ))
    if not passed:
        failed.append("feasibility_mean")
    
    # Gate 2: Feasibility (max violation)
    violation_max = metrics.get("violation_max", violation_mean)
    passed = violation_max <= config.violation_max
    results.append(GateResult(
        gate_id="feasibility_max",
        passed=passed,
        value=violation_max,
        threshold=config.violation_max,
        description=f"Max violation ≤ {config.violation_max}",
    ))
    if not passed:
        failed.append("feasibility_max")
    
    # Gate 3: Fidelity (drift)
    drift = metrics.get("drift_mean", metrics.get("drift", 0))
    passed = drift <= config.drift_max
    results.append(GateResult(
        gate_id="fidelity",
        passed=passed,
        value=drift,
        threshold=config.drift_max,
        description=f"Drift ≤ {config.drift_max}",
    ))
    if not passed:
        failed.append("fidelity")
    
    # Gate 4: Non-collapse
    collapse = metrics.get("collapse_score_mean", metrics.get("collapse_score", 0))
    passed = collapse >= config.collapse_min
    results.append(GateResult(
        gate_id="non_collapse",
        passed=passed,
        value=collapse,
        threshold=config.collapse_min,
        description=f"Variance ≥ {config.collapse_min}",
    ))
    if not passed:
        failed.append("non_collapse")
    
    # Gate 5: Responsiveness (latency)
    latency = metrics.get("latency_mean", 0)
    passed = latency <= config.latency_max
    results.append(GateResult(
        gate_id="responsiveness",
        passed=passed,
        value=latency,
        threshold=config.latency_max,
        description=f"Latency ≤ {config.latency_max}",
    ))
    if not passed:
        failed.append("responsiveness")
    
    # Gate 6: Structural sanity (Ricci)
    ricci = metrics.get("ricci_energy_mean", metrics.get("ricci_energy", 0))
    passed = ricci <= config.ricci_max
    results.append(GateResult(
        gate_id="structural",
        passed=passed,
        value=ricci,
        threshold=config.ricci_max,
        description=f"Ricci ≤ {config.ricci_max}",
    ))
    if not passed:
        failed.append("structural")
    
    # Gate 7: Consistency (if available)
    if "contradiction_rate" in metrics:
        contradiction = metrics["contradiction_rate"]
        passed = contradiction <= config.contradiction_max
        results.append(GateResult(
            gate_id="consistency",
            passed=passed,
            value=contradiction,
            threshold=config.contradiction_max,
            description=f"Contradiction ≤ {config.contradiction_max}",
        ))
        if not passed:
            failed.append("consistency")
    
    # Overall result
    overall_passed = len(failed) == 0
    
    if overall_passed:
        logger.info(f"All {len(results)} gates passed")
    else:
        logger.warning(f"{len(failed)} gates failed: {failed}")
    
    return GateReport(
        passed=overall_passed,
        failed_gates=failed,
        gate_results=results,
        metrics=metrics,
    )


def check_single_gate(
    gate_id: str,
    value: float,
    config: GateConfig,
) -> bool:
    """Check a single gate by ID.
    
    Args:
        gate_id: Gate identifier
        value: Metric value to check
        config: Gate configuration
        
    Returns:
        True if gate passes
    """
    thresholds = {
        "feasibility_mean": ("<=", config.violation_mean),
        "feasibility_max": ("<=", config.violation_max),
        "fidelity": ("<=", config.drift_max),
        "non_collapse": (">=", config.collapse_min),
        "responsiveness": ("<=", config.latency_max),
        "structural": ("<=", config.ricci_max),
        "consistency": ("<=", config.contradiction_max),
    }
    
    if gate_id not in thresholds:
        logger.warning(f"Unknown gate: {gate_id}")
        return True  # Unknown gates pass by default
    
    op, threshold = thresholds[gate_id]
    
    if op == "<=":
        return value <= threshold
    elif op == ">=":
        return value >= threshold
    else:
        return False


# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

def create_strict_config() -> GateConfig:
    """Create a strict gate configuration for production."""
    return GateConfig(
        violation_max=0.05,
        violation_mean=0.01,
        drift_max=0.5,
        collapse_min=0.05,
        latency_max=3.0,
    )


def create_relaxed_config() -> GateConfig:
    """Create a relaxed gate configuration for development."""
    return GateConfig(
        violation_max=0.5,
        violation_mean=0.2,
        drift_max=5.0,
        collapse_min=0.001,
        latency_max=20.0,
        ricci_max=1000.0,
    )


def format_report(report: GateReport) -> str:
    """Format a gate report for display.
    
    Args:
        report: GateReport to format
        
    Returns:
        Formatted string
    """
    lines = []
    lines.append(f"Gate Report: {'PASS' if report.passed else 'FAIL'}")
    lines.append("-" * 40)
    
    for gate in report.gate_results:
        status = "✓" if gate.passed else "✗"
        op = "≥" if "collapse" in gate.gate_id else "≤"
        lines.append(f"  {status} {gate.gate_id}: {gate.value:.4f} {op} {gate.threshold}")
    
    if report.failed_gates:
        lines.append(f"\nFailed: {', '.join(report.failed_gates)}")
    
    return "\n".join(lines)
