"""
ONN Core Tensor Data Structures

Implements the mathematical tensor objects defined in spec/11_interfaces.ir.yml:
- SemanticNode: A node S_i on the Semantic Manifold (Bound, Form, Intent fibers)
- SemanticEdge: A relationship E_ij between two nodes

Framework-agnostic: No ROS2, DDS, or external framework dependencies.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List
from enum import Enum


# -----------------------------------------------------------------------------
# Constants from spec/11_interfaces.ir.yml
# -----------------------------------------------------------------------------

BOUND_TENSOR_DIM = 16   # B_i: physical occupancy and collision boundaries
FORM_TENSOR_DIM = 32    # F_i: visual identity and invariant appearance
INTENT_TENSOR_DIM = 16  # I_i: functional affordances and task relevance


# -----------------------------------------------------------------------------
# SemanticNode
# -----------------------------------------------------------------------------

@dataclass
class SemanticNode:
    """
    A single node S_i on the Semantic Manifold.

    Represents an entity's existence via 3 fiber components:
    - bound_tensor (B_i): Encodes physical occupancy and collision boundaries
    - form_tensor (F_i): Encodes visual identity and invariant appearance
    - intent_tensor (I_i): Encodes functional affordances and task relevance

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> SemanticNode
    """

    node_id: int  # uint64: Unique persistent identifier for this anchor
    bound_tensor: np.ndarray = field(default_factory=lambda: np.zeros(BOUND_TENSOR_DIM, dtype=np.float32))
    form_tensor: np.ndarray = field(default_factory=lambda: np.zeros(FORM_TENSOR_DIM, dtype=np.float32))
    intent_tensor: np.ndarray = field(default_factory=lambda: np.zeros(INTENT_TENSOR_DIM, dtype=np.float32))

    def __post_init__(self):
        """Validate tensor dimensions and types."""
        self.bound_tensor = self._validate_tensor(self.bound_tensor, BOUND_TENSOR_DIM, "bound_tensor")
        self.form_tensor = self._validate_tensor(self.form_tensor, FORM_TENSOR_DIM, "form_tensor")
        self.intent_tensor = self._validate_tensor(self.intent_tensor, INTENT_TENSOR_DIM, "intent_tensor")

    @staticmethod
    def _validate_tensor(tensor: np.ndarray, expected_dim: int, name: str) -> np.ndarray:
        """Ensure tensor is correct shape and dtype."""
        arr = np.asarray(tensor, dtype=np.float32)
        if arr.shape != (expected_dim,):
            raise ValueError(f"{name} must have shape ({expected_dim},), got {arr.shape}")
        return arr

    def combined_state(self) -> np.ndarray:
        """
        Return the full state vector [B, F, I] concatenated.
        Total dimension: 16 + 32 + 16 = 64
        """
        return np.concatenate([self.bound_tensor, self.form_tensor, self.intent_tensor])

    def copy(self) -> SemanticNode:
        """Create a deep copy of this node."""
        return SemanticNode(
            node_id=self.node_id,
            bound_tensor=self.bound_tensor.copy(),
            form_tensor=self.form_tensor.copy(),
            intent_tensor=self.intent_tensor.copy()
        )

    def distance_to(self, other: SemanticNode) -> float:
        """
        Compute L2 distance between this node's state and another's.
        Used for constraint energy calculations.
        """
        return float(np.linalg.norm(self.combined_state() - other.combined_state()))


# -----------------------------------------------------------------------------
# SemanticEdge
# -----------------------------------------------------------------------------

@dataclass
class SemanticEdge:
    """
    A relationship E_ij between two SemanticNodes.

    The primary unit of topological existence in the ONN framework.
    "Existence is Relation" - an object persists because its relationships
    are topologically stable.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> SemanticEdge
    """

    source_id: int  # uint64: ID of the source node S_i
    target_id: int  # uint64: ID of the target node S_j
    relation_embedding: np.ndarray  # r_ij: Continuous vector representing relation nature
    weight: float = 1.0  # w_ij: Connection stiffness [0.0, inf)
    probability: float = 1.0  # p_ij: Existence confidence [0, 1]

    def __post_init__(self):
        """Validate edge properties."""
        self.relation_embedding = np.asarray(self.relation_embedding, dtype=np.float32)

        if self.weight < 0.0:
            raise ValueError(f"Edge weight must be >= 0, got {self.weight}")
        if not 0.0 <= self.probability <= 1.0:
            raise ValueError(f"Edge probability must be in [0, 1], got {self.probability}")

    @property
    def edge_key(self) -> tuple[int, int]:
        """Return (source_id, target_id) tuple for indexing."""
        return (self.source_id, self.target_id)

    def effective_strength(self) -> float:
        """
        Compute effective edge strength = weight * probability.
        Used for pruning low-confidence edges.
        """
        return self.weight * self.probability

    def copy(self) -> SemanticEdge:
        """Create a deep copy of this edge."""
        return SemanticEdge(
            source_id=self.source_id,
            target_id=self.target_id,
            relation_embedding=self.relation_embedding.copy(),
            weight=self.weight,
            probability=self.probability
        )


# -----------------------------------------------------------------------------
# Graph Containers (from spec/11_interfaces.ir.yml)
# -----------------------------------------------------------------------------

@dataclass
class RawSemanticGraph:
    """
    G_raw: The output of SEGO operator.

    A graph that may contain topological contradictions before
    the LOGOS solver runs.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> RawSemanticGraph
    """

    timestamp_ns: int  # Acquisition time in nanoseconds
    nodes: List[SemanticNode] = field(default_factory=list)
    edge_candidates: List[SemanticEdge] = field(default_factory=list)

    def get_node(self, node_id: int) -> Optional[SemanticNode]:
        """Retrieve node by ID, or None if not found."""
        for node in self.nodes:
            if node.node_id == node_id:
                return node
        return None

    def node_ids(self) -> List[int]:
        """Return list of all node IDs."""
        return [n.node_id for n in self.nodes]


@dataclass
class StabilizedGraph:
    """
    G_valid: The output of LOGOS operator.

    A graph where S and E satisfy the manifold constraints C.
    This is a topologically valid graph after the Projection-Consensus solver.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> StabilizedGraph
    """

    timestamp_ns: int  # Time of stabilization
    nodes: List[SemanticNode] = field(default_factory=list)
    edges: List[SemanticEdge] = field(default_factory=list)  # Validated edges (low-weight pruned)
    global_energy: float = 0.0  # Residual energy of the system (lower is better)
    
    # === CPL_003: Convergence gating for IMAGO ===
    is_valid: bool = True  # True if LOGOS converged, False if max_iter hit without convergence
    iterations_used: int = 0  # Number of solver iterations used

    def get_node(self, node_id: int) -> Optional[SemanticNode]:
        """Retrieve node by ID, or None if not found."""
        for node in self.nodes:
            if node.node_id == node_id:
                return node
        return None

    def get_edges_for_node(self, node_id: int) -> List[SemanticEdge]:
        """Get all edges connected to a given node (as source or target)."""
        return [e for e in self.edges if e.source_id == node_id or e.target_id == node_id]

    def node_ids(self) -> List[int]:
        """Return list of all node IDs."""
        return [n.node_id for n in self.nodes]

    def adjacency_dict(self) -> dict[int, List[int]]:
        """
        Build adjacency dictionary for graph algorithms.
        Returns {node_id: [neighbor_ids]}
        """
        adj: dict[int, List[int]] = {n.node_id: [] for n in self.nodes}
        for edge in self.edges:
            if edge.source_id in adj:
                adj[edge.source_id].append(edge.target_id)
            if edge.target_id in adj:
                adj[edge.target_id].append(edge.source_id)
        return adj


# -----------------------------------------------------------------------------
# ReasoningTrace (Output of IMAGO)
# -----------------------------------------------------------------------------

@dataclass
class ReasoningTrace:
    """
    R_trace: The output of IMAGO operator.

    A continuous signal defining the intended flow of the system state.
    Used by ORTSF to execute smooth, delay-compensated actions.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> ReasoningTrace
    """

    timestamp_ns: int  # Creation time
    target_state: List[SemanticNode] = field(default_factory=list)  # S*: desired future state
    trajectory_coeffs: np.ndarray = field(default_factory=lambda: np.array([], dtype=np.float32))
    curvature: float = 0.0  # Forman-Ricci curvature scalar of active cluster
    valid_until_ns: int = 0  # Expiration time for safety

    def is_valid(self, current_time_ns: int) -> bool:
        """Check if this trace is still valid at the given time."""
        return current_time_ns <= self.valid_until_ns


# -----------------------------------------------------------------------------
# Control Schemas
# -----------------------------------------------------------------------------

class ControlMode(Enum):
    """Control mode for ActuatorCommand."""
    POSITION = "POSITION"
    VELOCITY = "VELOCITY"
    TORQUE = "TORQUE"
    IMPEDANCE = "IMPEDANCE"


@dataclass
class ActuatorCommand:
    """
    u: The output of ORTSF. Computed control actions.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> ActuatorCommand
    """

    timestamp_ns: int
    mode: ControlMode
    command_values: np.ndarray  # Values corresponding to the mode

    def __post_init__(self):
        self.command_values = np.asarray(self.command_values, dtype=np.float32)


@dataclass
class JointState:
    """
    Standard proprioceptive state.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> JointState
    """

    position: np.ndarray  # Joint angles (radians) or positions (meters)
    velocity: np.ndarray  # Joint velocities
    effort: np.ndarray    # Joint torques/forces

    def __post_init__(self):
        self.position = np.asarray(self.position, dtype=np.float32)
        self.velocity = np.asarray(self.velocity, dtype=np.float32)
        self.effort = np.asarray(self.effort, dtype=np.float32)


@dataclass
class SensorObservation:
    """
    Z_i: The raw evidence package from HAL.

    Aggregates vision, depth, and proprioception.
    Note: rgb_images and depth_maps are represented as numpy arrays here.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> SensorObservation
    """

    timestamp_ns: int  # Acquisition time in nanoseconds
    frame_id: str      # Reference coordinate frame (e.g., 'robot_base')
    rgb_images: List[np.ndarray] = field(default_factory=list)
    depth_maps: List[np.ndarray] = field(default_factory=list)
    joint_state: Optional[JointState] = None


# -----------------------------------------------------------------------------
# Configuration Schemas
# -----------------------------------------------------------------------------

@dataclass
class MissionGoal:
    """
    High-level intent provided by the application layer.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> MissionGoal
    """

    goal_id: str       # Unique ID for this mission
    verb: str          # e.g., 'POUR', 'GRASP', 'MONITOR'
    target_node_id: int  # ID of the primary object of interest
    constraints: dict = field(default_factory=dict)  # Task-specific constraints


@dataclass
class ConstraintConfig:
    """
    Parameters for the LOGOS solver.

    Reference: spec/11_interfaces.ir.yml -> data_schemas -> ConstraintConfig
    """

    weights: dict[str, float] = field(default_factory=dict)  # Importance weights
    # CPL_007: Default matches spec/01_constraints.md (max_iterations=10)
    max_iterations: int = 10  # Budget for solver loop
    learning_rate: float = 0.01  # Eta: Step size for gradient descent
